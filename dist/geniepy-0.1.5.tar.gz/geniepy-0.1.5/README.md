# About

This is a simple python package used in my own PhD project to analyse and visualise cGENIE model output (mostly in netCDF format).

# Installation

```shell
python3 -m pip install -i https://test.pypi.org/simple/ foramgeniepy==0.1.5
```
