from pint import UnitRegistry
import pathlib


ureg = UnitRegistry()
Q_ = ureg.Quantity
file_path = pathlib.Path(__file__).parent.parent / "data/context.txt"
ureg.load_definitions(file_path)
